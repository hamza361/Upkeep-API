const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const cron = require('node-cron');
const axios = require('axios');

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, PUT ,OPTIONS ');
  next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


let sessionToken;
const FixedUrl = 'https://api.onupkeep.com/api/v2';
let filteredPartsRecords = [];
let filteredRecords = [];

const findMatchingParts = (purchaseOrdersGetArray, partsFilteredArray) => {
    // Create an array of results to store matching items
    const matchingParts = [];
    
    // Get the current date
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth(); // Current month (0-11)
    const currentYear = currentDate.getFullYear(); // Current year
  
    // Loop through each item in the partsFilteredArray
    partsFilteredArray.forEach(part => {
      // Loop through each item in the purchaseOrdersGetArray
      purchaseOrdersGetArray.forEach(order => {
        // Ensure partsPendingQuantities exists and is an object
        const partsPendingQuantities = order.partsPendingQuantities || {};
  
        // Parse the poDate string into a Date object
        const poDate = new Date(order.poDate);
        const poMonth = poDate.getMonth(); // PO month (0-11)
        const poYear = poDate.getFullYear(); // PO year
  
        // Check if partsPendingQuantities contains the id from partsFilteredArray,
        // if the month and year of poDate match the current month and year
        // or if the current month is greater than the poMonth, and currentYear is the same as poYear
        if (
          partsPendingQuantities[part.id] !== undefined && // Ensure it's defined
          (
            (poMonth === currentMonth && poYear === currentYear) || 
            (currentMonth > poMonth && currentYear === poYear)
          ) &&
          order.status !== "fulfilled"
        ) {
          matchingParts.push({
            purchaseOrderId: order.id,
            partId: part.id,
            status: order.status,
            totalQuantity: order.totalQuantity // Include totalQuantity in the match
          });
        }
      });
    });
  
    return matchingParts;
  };
  
  // Example execution
  const purchaseOrdersGetArray = [/* Your purchase orders */];
  const partsFilteredArray = [/* Your parts */];
  
  const matches = findMatchingParts(purchaseOrdersGetArray, partsFilteredArray);
  //console.log(matches);
  


const createPurchaseOrders = (dataArray) => {
   return dataArray.map(item => {
        
    const quantity = parseInt(item.maximumQuantity) 
        ? parseInt(item.maximumQuantity) - parseInt(item.quantity)
        : parseInt(item.minimumQuantity);
    
    const date = new Date();
    const year = date.getFullYear(); // Get the four-digit year
    const month = String(date.getMonth() + 1).padStart(2, '0'); // Get the month (0-11) and add 1, then pad with 0 if needed
    const day = String(date.getDate()).padStart(2, '0'); // Get the day of the month and pad with 0 if needed
      
     
        
     return {
      title: item.name,
      parts: [
        {
          id: item.id,
          quantity: 3
        }
      ],
      vendor: item.assignedVendors[0],
      description: item.description,
      poDate: `${year}-${month}-${day}`,

     
    }});
  };

const scheduleJob = async () => {

 sessionToken = 'r:27fb24d0ed3e9fafba6b1a6e50d368e5'; 


 // User credentials
 const userCredentials = {
    email: 'user@onupkeep.com',  // Replace with your actual email
    password: 'password'         // Replace with your actual password
  };

 // Perform the Session Token POST request
 try{
 const sessionResponse = await axios.post(`${FixedUrl}/auth`, userCredentials);

 // Check if the request was successful and extract the sessionToken
 if (sessionResponse.data.success) {
     
      sessionToken = response.data.result.sessionToken;
     
    } else {
      console.log('Authentication failed:', aessionResponse.data);
    }
  }
  catch(error) {
    // Handle errors
    console.error('Error during authentication:', error.message);
  };


  // Perform the Parts GET request
  try{
        const partsResponse = await axios.get(`${FixedUrl}/parts`, {
            headers: {
              'Session-Token': sessionToken,
              'Content-Type': 'application/json' 
            }
        });
    
        // Check if the request was successful and extract the Required Data
        if (partsResponse.data.success) {
         
            filteredPartsRecords = partsResponse.data.results.filter(item => parseInt(item.quantity) < parseInt(item.minimumQuantity && 
                item.cost !== undefined && item.cost !== null && item.cost >= 0 ));

         
        } else {
          console.log('Request failed:', partsResponse.data);
        }
  }
  catch(error) {
        // Handle errors
        console.error('Error during Parts Request:', error.message);
  };



  if(filteredPartsRecords.length > 0){

    try{
        const purchaseOrderGetResponse = await axios.get(`${FixedUrl}/purchase-orders/?status=approved&status=awaiting`, {
            headers: {
              'Session-Token': sessionToken,
              'Content-Type': 'application/json' 
            }
        });
        
        // Check if the request was successful and extract the Required Data
     
        if (purchaseOrderGetResponse.data.success) {
            //console.log("Purcahse Orders:", purchaseOrderGetResponse.data.results)
            //console.log("Filtered: ", filteredPartsRecords)
            const matches = findMatchingParts(purchaseOrderGetResponse.data.results, filteredPartsRecords);
            // Extract the IDs from excludeIds for easier comparison
            //console.log(filteredPartsRecords);
            //console.log(matches);
            const partIdsList = filteredPartsRecords.map(part => part.id);
            // Filter out matches that have partId in excludeIds
            const finalResults = matches.filter(match => partIdsList.includes(match.partId));
            filteredRecords = filteredPartsRecords.filter(exclude => !finalResults.some(match => match.partId == exclude.id));

    
        } else {
                  console.log('Request failed:', purchaseOrderGetResponse.data);
        }
        
        
    }catch(error) {
        // Handle errors
        console.error('Error during Purchase Order GET Request:', error.message);
    };


    if(filteredRecords.length > 0){
  
     var purchaseOrders = createPurchaseOrders(filteredRecords);
    }



    // Perform the Purchase Order POST request
    for (const order of purchaseOrders) {
        console.log(order);
        try{
            const purchaseOrderPostResponse = await axios.post(`${FixedUrl}/purchase-orders`, order, {
                headers: {
                  'Session-Token': sessionToken,
                  'Content-Type': 'application/json' 
                }
            });
    
            // Check if the request was successful and extract the Required Data
            if (purchaseOrderPostResponse.data.success) {
         
               console.log('PurchaseOrder Created Successfully:', purchaseOrderPostResponse.data);
                
         
            } else {
               console.log('Purchase Order Request failed:', purchaseOrderPostResponse.data);
            }
        }
        catch(error) {
            // Handle errors
            console.error('Error during Purchase Order Request:', error.response.data.message);
        };        
    }
  }
    




};

const deleteToken = async () => {

    axios.delete(`${FixedUrl}/auth`, {
        headers: {
          'Session-Token': sessionToken
        }
      })
      .then(response => {
        console.log('Session deleted successfully:', response.data);
      })
      .catch(error => {
        console.error('Error during session deletion:', error.response.data.message);
      });


}

//scheduleJob();


 cron.schedule('30 20 * * *', scheduleJob, {
   scheduled: true,
   timezone: "Etc/Greenwich"
 });

 deleteToken();


app.listen(3000);
