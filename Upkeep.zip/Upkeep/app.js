const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const cron = require('node-cron');
const axios = require('axios');

app.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept, Authorization');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PATCH, DELETE, PUT ,OPTIONS ');
  next();
});

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));


let sessionToken;
const FixedUrl = 'https://api.onupkeep.com/api/v2';
let filteredPartsRecords = [];
let filteredRecords = [];

const findMatchingParts = (purchaseOrdersGetArray, partsFilteredArray) => {
    // Create an array of results to store matching items
    const matchingParts = [];
    
    // Get the current date
    const currentDate = new Date();
    const currentMonth = currentDate.getMonth(); // Current month (0-11)
    const currentYear = currentDate.getFullYear(); // Current year
  
    // Loop through each item in the partsFilteredArray
    partsFilteredArray.forEach(part => {
      // Loop through each item in the purchaseOrdersGetArray
      purchaseOrdersGetArray.forEach(order => {
        // Ensure partsPendingQuantities exists and is an object
        const partsPendingQuantities = order.partsPendingQuantities || {};
  
        // Parse the poDate string into a Date object
        const poDate = new Date(order.poDate);
        const poMonth = poDate.getMonth(); // PO month (0-11)
        const poYear = poDate.getFullYear(); // PO year
  
        // Check if partsPendingQuantities contains the id from partsFilteredArray,
        // if the month and year of poDate match the current month and year
        // or if the current month is greater than the poMonth, and currentYear is the same as poYear
        if (
          partsPendingQuantities[part.id] !== undefined && // Ensure it's defined
          (
            (poMonth === currentMonth && poYear === currentYear) || 
            (currentMonth > poMonth && currentYear === poYear)
          ) &&
          order.status !== "fulfilled"
        ) {
          matchingParts.push({
            purchaseOrderId: order.id,
            partId: part.id,
            status: order.status,
            totalQuantity: order.totalQuantity // Include totalQuantity in the match
          });
        }
      });
    });
  
    return matchingParts;
  };  


// Create Purchase Order:
const createPurchaseOrders = (dataArray) => {
  // Count the frequency of each vendor
  const vendorCount = dataArray.reduce((acc, item) => {
    const vendor = item.assignedVendors[0] || `noVendor_${item.id}`;
    acc[vendor] = (acc[vendor] || 0) + 1;
    return acc;
  }, {});

  // Group records by vendor or handle no vendor assigned
  const groupedByVendor = dataArray.reduce((acc, item) => {
    const vendor = item.assignedVendors[0] || `noVendor_${item.id}`;

    // If the vendor appears only once or there’s no vendor, treat it as unique
    if (vendorCount[vendor] === 1 || vendor.startsWith('noVendor_')) {
      acc[`unique_${item.id}`] = [item];
    } else {
      // Otherwise, group by vendor
      if (!acc[vendor]) {
        acc[vendor] = [];
      }
      acc[vendor].push(item);
    }

    return acc;
  }, {});

  // Create purchase orders
  const purchaseOrders = Object.keys(groupedByVendor).map(groupKey => {
    const date = new Date();
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    const parts = groupedByVendor[groupKey].map(part => ({
      id: part.id,
      name: part.name, // Include the name for the title
      quantity: parseInt(part.maximumQuantity)
        ? parseInt(part.maximumQuantity) - parseInt(part.quantity)
        : parseInt(part.minimumQuantity)
    }));

    // Concatenate descriptions, filter out empty or undefined values
    let concatenatedDescription = groupedByVendor[groupKey]
      .map(part => part.description)
      .filter(description => description && description.trim()) // Filter out empty/undefined descriptions
      .join(', ');

    // If parts are grouped, concatenate names; otherwise use the first part's name
    const concatenatedNames = parts.length > 1 
      ? parts.map(part => part.name).join(', ') 
      : parts[0].name;

    // If vendor key starts with 'unique_' or 'noVendor_', we skip adding the vendor property
    const isUniqueOrNoVendor = groupKey.startsWith('unique_') || groupKey.startsWith('noVendor_');

    // If no description is found, use the title as the description
    if (!concatenatedDescription.trim()) {
      concatenatedDescription = `Purchase Order for ${concatenatedNames}`;
    }

    const purchaseOrder = {
      title: `Purchase Order for ${concatenatedNames}`, // Title includes part names
      parts: parts,
      description: concatenatedDescription, // Default to concatenated descriptions or title
      poDate: `${year}-${month}-${day}` // Format date as YYYY-MM-DD
    };

    // Only add vendor property if there's a valid vendor
    if (!isUniqueOrNoVendor) {
      purchaseOrder.vendor = groupKey;
    }

    return purchaseOrder;
  });

  return purchaseOrders;
};

  



const scheduleJob = async () => {

 sessionToken = 'r:27fb24d0ed3e9fafba6b1a6e50d368e5'; 


 // User credentials
 const userCredentials = {
    email: 'logan.woods@columbia-fruit.com',  // Replace with your actual email
    password: 'Upkeep@123'         // Replace with your actual password
  };

 // Perform the Session Token POST request
 try{
 const sessionResponse = await axios.post(`${FixedUrl}/auth`, userCredentials);

 // Check if the request was successful and extract the sessionToken
 if (sessionResponse.data.success) {
     
      sessionToken = sessionResponse.data.result.sessionToken;
     
    } else {
      console.log('Authentication failed:', sessionResponse.data);
    }
  }
  catch(error) {
    // Handle errors
    console.error('Error during authentication:', error.response.data.message);
  };


  // Perform the Parts GET request
  try{
        const partsResponse = await axios.get(`${FixedUrl}/parts?location=sNOjlFrvfM`, {
            headers: {
              'Session-Token': sessionToken,
              'Content-Type': 'application/json' 
            }
        });
    
        // Check if the request was successful and extract the Required Data
        //console.log("Parts API:", partsResponse.data.results)
        if (partsResponse.data.success) {
            
            filteredPartsRecords = partsResponse.data.results.filter(item => parseInt(item.quantity) < parseInt(item.minimumQuantity) 
              && item.cost !== undefined && item.cost !== null 
              && parseInt(item.cost) >= 0 
              );
            //filteredPartsRecords = partsResponse.data.results;

         
        } else {
          console.log('Request failed:', partsResponse.data);
        }
  }
  catch(error) {
        // Handle errors
        console.error('Error during Parts Request:', error.response.data.message);
  };


  //console.log("Filtered Part Records:", filteredPartsRecords);
  if(filteredPartsRecords.length > 0){

    try{
        const purchaseOrderGetResponse = await axios.get(`${FixedUrl}/purchase-orders/?status=approved&status=awaiting`, {
            headers: {
              'Session-Token': sessionToken,
              'Content-Type': 'application/json' 
            }
        });
        
        // Check if the request was successful and extract the Required Data
     
        if (purchaseOrderGetResponse.data.success) {
            //console.log("Purcahse Orders:", purchaseOrderGetResponse.data.results)
            //console.log("Filtered: ", filteredPartsRecords)
            const matches = findMatchingParts(purchaseOrderGetResponse.data.results, filteredPartsRecords);
            // Extract the IDs from excludeIds for easier comparison
            //console.log(filteredPartsRecords);
            //console.log(matches);
            const partIdsList = filteredPartsRecords.map(part => part.id);
            // Filter out matches that have partId in excludeIds
            const finalResults = matches.filter(match => partIdsList.includes(match.partId));
            filteredRecords = filteredPartsRecords.filter(exclude => !finalResults.some(match => match.partId == exclude.id));

    
        } else {
                  console.log('Purchase Order Get Request failed:', purchaseOrderGetResponse.data);
        }
        
        
    }catch(error) {
        // Handle errors
        console.error('Error during Purchase Order GET Request:', error.response.data.message);
    };

   
    if(filteredRecords.length > 0){
     var purchaseOrders = createPurchaseOrders(filteredRecords);    
    }



    // Perform the Purchase Order POST request
    for (const order of purchaseOrders) {
        console.log(order);
        try{
            const purchaseOrderPostResponse = await axios.post(`${FixedUrl}/purchase-orders`, order, {
                headers: {
                  'Session-Token': sessionToken,
                  'Content-Type': 'application/json' 
                }
            });
    
            // Check if the request was successful and extract the Required Data
            if (purchaseOrderPostResponse.data.success) {
         
               console.log('PurchaseOrder Created Successfully:', purchaseOrderPostResponse.data);
                
         
            } else {
               console.log('Purchase Order Request failed:', purchaseOrderPostResponse.data);
            }
        }
        catch(error) {
            // Handle errors
            console.error('Error during Purchase Order Request:', error.response.data.message);
        };        
    }
    
    deleteToken();
  }
    

  


};

const deleteToken = async () => {

    axios.delete(`${FixedUrl}/auth`, {
        headers: {
          'Session-Token': sessionToken
        }
      })
      .then(response => {
        console.log('Session deleted successfully:', response.data);
      })
      .catch(error => {
        console.error('Error during session deletion:', error.response.data.message);
      });


}

//scheduleJob();


 cron.schedule('30 20 * * *', scheduleJob, {
   scheduled: true,
   timezone: "Etc/Greenwich"
 });




app.listen(3000);
